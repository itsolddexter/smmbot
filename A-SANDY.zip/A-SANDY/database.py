import sqlite3

def init_db():
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            referred INTEGER DEFAULT 0,
            referby INTEGER DEFAULT 0,
            instagram_service INTEGER DEFAULT 0,
            telegram_service INTEGER DEFAULT 0,
            youtube_service INTEGER DEFAULT 0,
            refer TEXT DEFAULT '{}'
        )
    ''')
    conn.commit()
    conn.close()

def get_user_data(user_id):
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            'id': row[0],
            'referred': row[1],
            'referby': row[2],
            'instagram_service': row[3],
            'telegram_service': row[4],
            'youtube_service': row[5],
            'refer': eval(row[6])
        }
    return None

def save_user_data(user_id, data):
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users 
        (id, referred, referby, instagram_service, telegram_service, youtube_service, refer)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        user_id,
        data['referred'],
        data['referby'],
        data['instagram_service'],
        data['telegram_service'],
        data['youtube_service'],
        str(data['refer'])
    ))
    conn.commit()
    conn.close()

def get_all_user_ids():
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM users')
    ids = [row[0] for row in cursor.fetchall()]
    conn.close()
    return ids

def count_total_users():
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM users')
    count = cursor.fetchone()[0]
    conn.close()
    return count