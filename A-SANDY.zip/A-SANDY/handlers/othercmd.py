from aiogram import types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

async def instagram_handler(msg: types.Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
    KeyboardButton("⚡ Buy Followers"), KeyboardButton("❤ Buy Likes")
    )
    keyboard.add(
    KeyboardButton("✅ Buy Comments"), KeyboardButton("👁 Buy Views")
    )
    keyboard.add(
    KeyboardButton("🚀 Buy Stories"), KeyboardButton("🤹‍♂ Buy Live")
    )
    keyboard.add(KeyboardButton("« Back"))
    
    await msg.answer_photo(photo="https://t.me/SandeshClaude/9")
    text = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] {msg.from_user.first_name}</b> <code>This is our Instagram Service!!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Boost your Instagram with followers, likes, comments & more – starting from just ₹10!</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b> <code>Please select a service below!</code>"""
    await msg.answer(text, parse_mode="HTML", reply_markup=keyboard)
    
async def youtube_handler(msg: types.Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
    KeyboardButton("🚀 Buy Subscribers"), KeyboardButton("💖 Buy Likes")
    )
    keyboard.add(
    KeyboardButton("🎯 Buy Stream Views"), KeyboardButton("📈 Buy Views")
    )
    keyboard.add(KeyboardButton("« Back"))

    text = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] {msg.from_user.first_name}</b> <code>This is our YouTube Service!!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Boost your YouTube with subscribres, likes & more – starting from just ₹50!</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b> <code>Please select a service below!</code>"""
    await msg.answer(text, parse_mode="HTML", reply_markup=keyboard)    
    
async def telegram_handler(msg: types.Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
    KeyboardButton("✨ Buy Members"),
    KeyboardButton("🔥 Buy Reaction")
    )
    keyboard.add(KeyboardButton("📈 Buy Post Views")
    )
    keyboard.add(KeyboardButton("« Back"))

    text = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] {msg.from_user.first_name}</b> <code>This is our Telegram Service!!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Boost your Telegram with members, reactions & views – starting from just ₹25!</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b> <code>Please select a service below!</code>"""
    await msg.answer(text, parse_mode="HTML", reply_markup=keyboard)        