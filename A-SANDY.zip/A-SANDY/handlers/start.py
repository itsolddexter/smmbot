from aiogram import types
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from config import CHANNELS, PER_REFER, coin
import sqlite3
from aiogram.utils.exceptions import BotBlocked, ChatNotFound, MessageToDeleteNotFound, BadRequest, MessageNotModified, RetryAfter

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

async def menu(bot, user_id):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton("Instagram Service"),
        KeyboardButton("Telegram Service")
    )
    keyboard.add(
        KeyboardButton("YouTube Service")
    )

    caption = """<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Welcome to the SocialSphereBot!</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] What can this bot do?</b>
Boost <b>followers</b>, <b>likes</b>, <b>subscribers</b>, and <b>views</b> instantly on:

<b>• Instagram</b>
<b>• Telegram</b>
<b>• YouTube</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Why choose us?</b>
✅ <b>Fast & Secure</b>  
✅ <b>Real Engagement</b>  
✅ <b>24/7 Service</b>  
✅ <b>Starts at just ₹10!</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Try now and grow your social presence!</b>"""

    #await bot.send_message(user_id, caption, parse_mode="HTML", reply_markup=keyboard)
    await bot.send_video(
            chat_id=user_id,
            video="https://t.me/SandeshClaude/7",
            caption=caption,
            parse_mode="HTML",
          #  disable_web_page_preview=True,
            reply_markup=keyboard
        )
    
async def checkforyou(bot, user_id):
    for channel in CHANNELS:
        try:
            member = await bot.get_chat_member(channel, user_id)
            if member.status in ['left', 'kicked']:
                return False
        except Exception as e:
            print(f"Error checking channel {channel} for user {user_id}: {e}")
            return False
    return True    
    
#async def send_service_menu(bot, user_id):
#    markup = InlineKeyboardMarkup()
#    markup.add(InlineKeyboardButton(text="Instagram Service", callback_data="instagram_service"))
#    markup.add(InlineKeyboardButton(text="Telegram Service", callback_data="telegram_service"))
#    markup.add(InlineKeyboardButton(text="YouTube Service", callback_data="youtube_service"))
#    msg_menu = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Choose the service you want to use:</code>"""
#    await bot.send_message(user_id, msg_menu, parse_mode="HTML", reply_markup=markup)
    
async def start_handler(msg: Message):
    bot = msg.bot
    user_id = str(msg.from_user.id)
    msg_text = msg.text

    conn = sqlite3.connect("user_data.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user_data = cur.fetchone()

    if msg_text == "/start":
        if user_data is None:
            cur.execute('''
                INSERT INTO users (id, referred, referby, balance, refer, instagram_service, telegram_service, youtube_service)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (int(user_id), 0, int(user_id), 0, '', 0, 0, 0))
            conn.commit()

            gconn = sqlite3.connect("global_data.db")
            gcur = gconn.cursor()
            gcur.execute("UPDATE global_stats SET value = value + 1 WHERE key = 'total_users'")
            gconn.commit()
            gconn.close()

        markup = InlineKeyboardMarkup()
        markup.add(
            InlineKeyboardButton("𝑭𝒐𝒍𝒍𝒐𝒘 𝑴𝒆 𝑶𝒏 𝑰𝒏𝒔𝒕𝒂", url="https://www.instagram.com/6_hf0")
        )
        markup.add(
            InlineKeyboardButton("𝗝𝗢𝗜𝗡", url="https://t.me/URxFF")
        )
        markup.add(
            InlineKeyboardButton("✅ 𝑰’𝒗𝒆 𝑱𝒐𝒊𝒏𝒆𝒅 – 𝑪𝒐𝒏𝒕𝒊𝒏𝒖𝒆", callback_data="check")
        )

        msg_start = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Welcome to the Ultimate SMM Panel Bot!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] ⚡ Boost Your Social Media:</b>
<pre>Grow fast on Instagram, Telegram & YouTube.</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 💸 Affordable Services:</b>
<pre>Start boosting your social media for as low as ₹10!</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 🔐 Fast & Secure:</b>
<pre>Get real engagement with 24/7 service. Safe and easy to use.</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> ⚠️ Once done, click the button below to continue to the Dashboard.</code>"""

        await bot.send_message(user_id, msg_start, parse_mode="HTML", disable_web_page_preview=True, reply_markup=markup)

    else:
        try:
            refid = str(int(msg_text.split()[1]))
        except:
            refid = user_id

        if user_data is None:
            cur.execute('''
                INSERT INTO users (id, referred, referby, balance, refer, instagram_service, telegram_service, youtube_service)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (int(user_id), 0, int(refid), 0, '', 0, 0, 0))
            conn.commit()

            gconn = sqlite3.connect("global_data.db")
            gcur = gconn.cursor()
            gcur.execute("UPDATE global_stats SET value = value + 1 WHERE key = 'total_users'")
            gconn.commit()
            gconn.close()

        markup = InlineKeyboardMarkup()
        markup.add(
            InlineKeyboardButton("𝑭𝒐𝒍𝒍𝒐𝒘 𝑴𝒆 𝑶𝒏 𝑰𝒏𝒔𝒕𝒂", url="https://www.instagram.com/6_hf0")
        )
        markup.add(
            InlineKeyboardButton("𝗝𝗢𝗜𝗡", url="https://t.me/URxFF")
        )
        markup.add(
            InlineKeyboardButton("✅ 𝑰’𝒗𝒆 𝑱𝒐𝒊𝒏𝒆𝒅 – 𝑪𝒐𝒏𝒕𝒊𝒏𝒖𝒆", callback_data="check")
        )

        msg_start = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Welcome to the Ultimate SMM Panel Bot!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] ⚡ Boost Your Social Media:</b>
<pre>Grow fast on Instagram, Telegram & YouTube.</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 💸 Affordable Services:</b>
<pre>Start boosting your social media for as low as ₹10!</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 🔐 Fast & Secure:</b>
<pre>Get real engagement with 24/7 service. Safe and easy to use.</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> ⚠️ Once done, click the button below to continue to the Dashboard.</code>"""

        await bot.send_message(user_id, msg_start, parse_mode="HTML", disable_web_page_preview=True, reply_markup=markup)

    conn.close()

#@dp.callback_query_handler(lambda call: call.data == "check")
async def check_callback_handler(call: types.CallbackQuery):
    bot = call.bot
    user_id = str(call.from_user.id)

    try:
        await bot.answer_callback_query(call.id, text="Processing...", show_alert=False)
        ch = await checkforyou(bot, call.message.chat.id)

        conn = sqlite3.connect("user_data.db")
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user_data = cur.fetchone()

        if ch and user_data:
            try:
                await bot.delete_message(call.message.chat.id, call.message.message_id)
            except MessageToDeleteNotFound:
                pass

            referby = user_data["referby"]
            if not referby or not str(referby).isdigit():
                referby = user_id
                cur.execute("UPDATE users SET referby = ? WHERE id = ?", (user_id, user_id))
                conn.commit()

            if int(referby) != int(user_id):
                cur.execute("SELECT * FROM users WHERE id = ?", (referby,))
                ref_data = cur.fetchone()

                referred_ids = (ref_data["refer"] or "").split(",") if ref_data else []

                if user_id not in referred_ids:
                    new_balance = ref_data["balance"] + PER_REFER
                    new_referred = ref_data["referred"] + 1
                    new_refer = (ref_data["refer"] or "") + f"{user_id},"

                    cur.execute("UPDATE users SET balance = ?, referred = ?, refer = ? WHERE id = ?", (new_balance, new_referred, new_refer, referby))
                    conn.commit()

                    try:
                        referred_user = f'<a href="tg://user?id={user_id}">{call.from_user.first_name}</a>'
                        await bot.send_message(referby, f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b><code> Refer successful!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] You referred:</b> <code>{referred_user}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] You Got:</b> <code>{PER_REFER} {coin}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Tip:</b> <code>Refer more to earn more!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Developer:</b><code> Sandesh Vaiya</code>""", parse_mode="HTML", disable_web_page_preview=True)
                    except (BotBlocked, ChatNotFound):
                        pass

            await menu(bot, call.from_user.id)

        else:
            try:
                await bot.delete_message(call.message.chat.id, call.message.message_id)
            except MessageToDeleteNotFound:
                pass

            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("𝑭𝒐𝒍𝒍𝒐𝒘 𝑴𝒆 𝑶𝒏 𝑰𝒏𝒔𝒕𝒂", url='https://www.instagram.com/6_hf0'))
            markup.add(
                InlineKeyboardButton('𝗝𝗢𝗜𝗡', url='https://t.me/URxFF')
            )
            markup.add(InlineKeyboardButton("✅ 𝑰’𝒗𝒆 𝑱𝒐𝒊𝒏𝒆𝒅 – 𝑪𝒐𝒏𝒕𝒊𝒏𝒖𝒆", callback_data='check'))

            msg_start = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Welcome to the Ultimate SMM Panel Bot!</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] ⚡ Boost Your Social Media:</b>
<pre>Grow fast on Instagram, Telegram & YouTube.</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 💸 Affordable Services:</b>
<pre>Start boosting your social media for as low as ₹10!</pre>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] 🔐 Fast & Secure:</b>
<pre>Get real engagement with 24/7 service. Safe and easy to use.</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> ⚠️ Once done, click the button below to continue to the Dashboard.</code>"""

            await bot.send_message(user_id, msg_start, parse_mode="HTML", disable_web_page_preview=True, reply_markup=markup)

        conn.close()

    except (BadRequest, MessageNotModified, RetryAfter):
        pass