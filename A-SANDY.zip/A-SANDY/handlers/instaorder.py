from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher
import instaloader
import re
import random
import string
import sqlite3
from config import ADMIN_ID
from handlers.instaservice import send_followers_prices, send_likes_prices, send_comments_prices, send_views_prices, send_stories_prices, send_live_prices

user_order_state = {}

valid_services = {
    "1k Instagram Followers ₹110": "Followers",
    "5k Instagram Followers ₹450": "Followers",
    "10k Instagram Followers ₹850": "Followers",
    "1k Instagram Likes ₹11": "Likes",
    "2k Instagram Likes ₹21": "Likes",
    "5k Instagram Likes ₹50": "Likes",
    "10k Instagram Likes ₹90": "Likes",
    "2k Instagram Views ₹5": "Views",
    "5k Instagram Views ₹10": "Views",
    "10k Instagram Views ₹15": "Views",
    "50k Instagram Views ₹60": "Views",
    "100k Instagram Views ₹100": "Views",
    "1M Instagram Views ₹710": "Views",
    "500 Instagram Comments ₹50": "Comments",
    "1k Instagram Comments ₹90": "Comments",
    "5k Instagram Comments ₹400": "Comments",
    "10k Instagram Comments ₹750": "Comments",
    "1k Live Stream Views ₹80": "Live",
    "5k Live Stream Views ₹350": "Live",
    "10k Live Stream Views ₹600": "Live",
    "1k Instagram Story Views ₹20": "Stories",
    "5k Instagram Story Views ₹90": "Stories",
    "10k Instagram Story Views ₹160": "Stories"
}


def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))

def extract_username(text):
    match = re.search(r"(?:https?://)?(?:www\.)?instagram\.com/([\w\.]+)|@?(\w+)", text)
    if match:
        return match.group(1) or match.group(2)
    return None

async def handle_order_selection(message: Message):
    if message.text not in valid_services:
        return
    user_order_state[message.from_user.id] = {
        "service": message.text,
        "step": "awaiting_username"
    }
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("❌ Cancel Order"))
    await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Please send the Instagram username or profile link:</i></b>", reply_markup=keyboard, parse_mode="HTML")

async def process_instagram_username(message: Message):
    user_id = message.from_user.id
    if user_id not in user_order_state:
        return
    state = user_order_state[user_id]
    if state.get("step") != "awaiting_username":
        return
    username = extract_username(message.text)
    if not username:
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Invalid username or link. Please resend.</b>", parse_mode="HTML")
        return
    loader = instaloader.Instaloader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
        if profile.is_private:
            del user_order_state[user_id]
            await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] This account is private. Please make it public.</b>", parse_mode="HTML")
            await redirect_to_service(message, state["service"])
            return
    except:
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Couldn't fetch details. Please resend a valid username.</b>", parse_mode="HTML")
        return
    order_id = generate_order_id()
    state["step"] = "awaiting_payment"
    state["username"] = username
    state["order_id"] = order_id
    bio = profile.biography or "Not Available!!!"
    state["profile_info"] = {
    "bio": bio,
    "followers": profile.followers
    }
    service_text = state['service']
    amount = service_text.split("₹")[-1]
    service_name = service_text.replace(f"₹{amount}", "").strip()
    caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Instagram Order Details</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Amount To Pay:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order_id}</code>    
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>👁‍🗨</a>] Account Infomation:</b>

<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Username:</b> <code>{profile.username}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Name:</b> <code>{profile.full_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Followers:</b> <code>{profile.followers}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Bio:</b> <code>{bio}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Note:</b> <code>⚠️ If you have sent the payment, please send a screenshot below.</code>"""

#    caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Instagram Order Details</b>
#- - - - - - - - - - - - - - - - - - - - - - - -
#<b>Username:</b> <code>{profile.username}</code>
#<b>Name:</b> {profile.full_name}
#<b>Followers:</b> <code>{profile.followers}</code>
#<b>Bio:</b> <code>{bio}</code>
#- - - - - - - - - - - - - - - - - - - - - - - -
#<b>Amount To Pay:</b> <code>₹{amount}</code>
#<b>Service:</b> <code>{service_name}</code>
#<b>Order ID:</b> <code>{order_id}</code>
#<b>Note:</b> <i>If you have sent the payment, please send a screenshot below.</i>"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("❌ Cancel Order"))
    await message.answer_photo("https://iili.io/3wsXU0u.jpg", caption=caption, parse_mode="HTML", reply_markup=keyboard)

async def cancel_order(message: Message):
    user_id = message.from_user.id
    if user_id in user_order_state:
        service = user_order_state[user_id].get("service")
        del user_order_state[user_id]
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order has been cancelled.</b>", parse_mode="HTML")
        await redirect_to_service(message, service)

async def handle_payment_screenshot(message: Message):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    
    if user_id in user_order_state and message.photo:
        order = user_order_state[user_id]
        del user_order_state[user_id]
        amount = order['service'].split("₹")[-1]
        service_name = order['service'].replace(f"₹{amount}", "").strip()
        profile_info = order.get("profile_info", {})
        bio = profile_info.get("bio", "Not Available!!!")
        followers = profile_info.get("followers", "Not Found")
        caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] New Instagram Order Received</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order['order_id']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Amount Been Pay:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Username:</b> <code>{order['username']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Followers:</b> <code>{followers}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Bio:</b> <code>{bio}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] User:</b> <a href="tg://user?id={user_id}">{message.from_user.first_name}</a>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Action:</b> This order is awaiting approval."""
        await message.bot.send_photo(ADMIN_ID, message.photo[-1].file_id, caption=caption, parse_mode="HTML")
        conn = sqlite3.connect("user_data.db")
        cur = conn.cursor()
        cur.execute("UPDATE users SET instagram_service = instagram_service + 1 WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        
        confirmation = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Hindi:</b>  
<pre>आपका ऑर्डर प्रोसेस हो रहा है ⚙️  
कृपया धैर्य रखें ⏳  
8 घंटे के अंदर आपका ऑर्डर पूरा कर दिया जाएगा ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] English:</b>  
<pre>Your order is currently being processed ⚙️  
Please be patient ⏳  
Your order will be completed within 8 hours ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Note:</b>  
<code>If you didn’t receive the order, please contact our support team or join the group.</code>"""
        await message.answer(confirmation, parse_mode="HTML")
        await redirect_to_service(message, order["service"])

async def redirect_to_service(message: Message, service: str):
    if "Followers" in service:
        await send_followers_prices(message)
    elif "Likes" in service:
        await send_likes_prices(message)
    elif "Comments" in service:
        await send_comments_prices(message)
    elif "Views" in service and "Story" not in service and "Live" not in service:
        await send_views_prices(message)
    elif "Story" in service:
        await send_stories_prices(message)
    elif "Live" in service:
        await send_live_prices(message)

def register_instaorder_handlers(dp: Dispatcher):
    dp.register_message_handler(cancel_order, lambda m: m.text == "❌ Cancel Order")
    dp.register_message_handler(handle_order_selection, lambda m: m.text in valid_services)
    dp.register_message_handler(process_instagram_username)
    dp.register_message_handler(handle_payment_screenshot, content_types=types.ContentType.PHOTO)