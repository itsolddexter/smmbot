from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher
import re
import random
import string
import sqlite3
from config import ADMIN_ID
from handlers.youtubeservice import send_subscribres_prices, send_ytlikes_prices, send_ytviews_prices, send_stream_prices

user_order_state = {}

valid_services = {
    "1k Youtube Subscriber ₹205": "Subscribers",
    "5k Youtube Subscriber ₹900": "Subscribers",
    "10k Youtube Subscriber ₹1800": "Subscribers",
    "1k Youtube Likes ₹65": "Likes",
    "5k Youtube Likes ₹300": "Likes",
    "10k Youtube Likes ₹500": "Likes",
    "1k Youtube Views ₹110": "Views",
    "5k Youtube Views ₹500": "Views",
    "10k Youtube Views ₹900": "Views",
    "1k Youtube Live Stream Views ₹50": "Live",
    "5k Youtube Live Stream Views ₹200": "Live",
    "10k Youtube Live Stream Views ₹350": "Live"
}

def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))

def is_valid_youtube_link(text):
    return bool(re.match(r"^(https?://)?(www\.)?(youtube\.com|youtu\.be)/.+$", text))

async def handle_order_selection(message: Message):
    if message.text not in valid_services:
        return
    user_order_state[message.from_user.id] = {
        "service": message.text,
        "step": "awaiting_link"
    }
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🚫 Cancel Order"))
    await message.answer("""
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Please send the YouTube video/channel/profile link:</i></b>
    """, parse_mode="HTML", reply_markup=keyboard)

async def process_youtube_link(message: Message):
    user_id = message.from_user.id
    if user_id not in user_order_state:
        return
    state = user_order_state[user_id]
    if state.get("step") != "awaiting_link":
        return
    if not is_valid_youtube_link(message.text):
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Invalid YouTube link. Please resend.</b>", parse_mode="HTML")
        return

    order_id = generate_order_id()
    state["step"] = "awaiting_payment"
    state["ytlink"] = message.text
    state["order_id"] = order_id
    service_text = state['service']
    amount = service_text.split("\u20b9")[-1]
    service_name = service_text.replace(f"₹{amount}", "").strip()

    caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] YouTube Order Details</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Amount To Pay:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Order ID:</b> <code>{order_id}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Link:</b> <a href='{state['ytlink']}'>Click Here</a>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <code>⚠️ If you have sent the payment, please send a screenshot below.</code>
"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🚫 Cancel Order"))
    await message.answer_photo("https://iili.io/3wsXU0u.jpg", caption=caption, parse_mode="HTML", reply_markup=keyboard)

async def cancel_o3der(message: Message):
    user_id = message.from_user.id
    if user_id in user_order_state:
        service = user_order_state[user_id].get("service")
        del user_order_state[user_id]
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order has been cancelled.</b>", parse_mode="HTML")
        await redirect_to_service(message, service)

async def handle_payment_screenshot(message: Message):
    user_id = message.from_user.id
    if user_id in user_order_state and message.photo:
        order = user_order_state[user_id]
        del user_order_state[user_id]

        amount = order['service'].split("\u20b9")[-1]
        service_name = order['service'].replace(f"₹{amount}", "").strip()

        caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] New YouTube Order Received</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Order ID:</b> <code>{order['order_id']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Amount Paid:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>Link:</b> <a href='{order['ytlink']}'>Click Here</a>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] User:</b> <a href="tg://user?id={user_id}">{message.from_user.first_name}</a>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Action:</b> This order is awaiting approval."""

        conn = sqlite3.connect("user_data.db")
        cur = conn.cursor()
        cur.execute("UPDATE users SET youtube_service = youtube_service + 1 WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()

        await message.bot.send_photo(ADMIN_ID, message.photo[-1].file_id, caption=caption, parse_mode="HTML")

        confirmation = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Hindi:</b>  
<pre>आपका ऑर्डर प्रोसेस हो रहा है ⚙️  
कृपया धैर्य रखें ⏳  
8 घंटे के अंदर आपका ऑर्डर पूरा कर दिया जाएगा ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] English:</b>  
<pre>Your order is currently being processed ⚙️  
Please be patient ⏳  
Your order will be completed within 8 hours ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Note:</b>  
<code>If you didn’t receive the order, please contact our support team or join the group.</code>"""

        await message.answer(confirmation, parse_mode="HTML")
        await redirect_to_service(message, order["service"])

async def redirect_to_service(message: Message, service: str):
    if "Subscribers" in service:
        await send_subscribres_prices(message)
    elif "Likes" in service:
        await send_ytlikes_prices(message)
    elif "Views" in service and "Stream" not in service:
        await send_ytviews_prices(message)
    elif "Stream" in service:
        await send_stream_prices(message)

def register_ytorder_handlers(dp: Dispatcher):
    dp.register_message_handler(cancel_o3der, lambda m: m.text == "🚫 Cancel Order")
    dp.register_message_handler(handle_order_selection, lambda m: m.text in valid_services)
    dp.register_message_handler(process_youtube_link)
    dp.register_message_handler(handle_payment_screenshot, content_types=types.ContentType.PHOTO)
