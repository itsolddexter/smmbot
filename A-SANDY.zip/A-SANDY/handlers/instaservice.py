from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher

#async def send_instagram_menu(message: Message):
#    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
#    keyboard.add(
#        KeyboardButton("⚡ Buy Followers"), KeyboardButton("❤ Buy Likes")
#    )
#    keyboard.add(
#        KeyboardButton("✅ Buy Comments"), KeyboardButton("👁 Buy Views")
#    )
#    keyboard.add(
#        KeyboardButton("🚀 Buy Stories"), KeyboardButton("🤹‍♂ Buy Live")
#    )
#    keyboard.add(
#        KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard")
#    )

#    caption = (
#        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>{}</b> This is our Instagram Service !!\n"
#        "<i>Please select a service below!</i>"
#    )
#    name = message.from_user.first_name
#    await message.answer(caption.format(name), reply_markup=keyboard, parse_mode="HTML")


async def send_followers_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Instagram Followers ₹110"))
    keyboard.add(KeyboardButton("5k Instagram Followers ₹450"))
    keyboard.add(KeyboardButton("10k Instagram Followers ₹850"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Followers package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )


async def send_likes_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Instagram Likes ₹11"))
    keyboard.add(KeyboardButton("2k Instagram Likes ₹21"))
    keyboard.add(KeyboardButton("5k Instagram Likes ₹50"))
    keyboard.add(KeyboardButton("10k Instagram Likes ₹90"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Likes package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )


async def send_views_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("2k Instagram Views ₹5"))
    keyboard.add(KeyboardButton("5k Instagram Views ₹10"))
    keyboard.add(KeyboardButton("10k Instagram Views ₹15"))
    keyboard.add(KeyboardButton("50k Instagram Views ₹60"))
    keyboard.add(KeyboardButton("100k Instagram Views ₹100"))
    keyboard.add(KeyboardButton("1M Instagram Views ₹710"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_comments_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("500 Instagram Comments ₹50"))
    keyboard.add(KeyboardButton("1k Instagram Comments ₹90"))
    keyboard.add(KeyboardButton("5k Instagram Comments ₹400"))
    keyboard.add(KeyboardButton("10k Instagram Comments ₹750"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Comments package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )


async def send_stories_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Instagram Story Views ₹20"))
    keyboard.add(KeyboardButton("5k Instagram Story Views ₹90"))
    keyboard.add(KeyboardButton("10k Instagram Story Views ₹160"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Story Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )


async def send_live_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Live Stream Views ₹80"))
    keyboard.add(KeyboardButton("5k Live Stream Views ₹350"))
    keyboard.add(KeyboardButton("10k Live Stream Views ₹600"))
    keyboard.add(KeyboardButton("‹‹ Back"), KeyboardButton("« Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Instagram Live Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

def register_instaservice_handlers(dp: Dispatcher):
  #  dp.register_message_handler(send_instagram_menu, lambda msg: msg.text == "Instagram Service")
    dp.register_message_handler(send_followers_prices, lambda msg: msg.text == "⚡ Buy Followers")
    dp.register_message_handler(send_likes_prices, lambda msg: msg.text == "❤ Buy Likes")
    dp.register_message_handler(send_comments_prices, lambda msg: msg.text == "✅ Buy Comments")
    dp.register_message_handler(send_views_prices, lambda msg: msg.text == "👁 Buy Views")
    dp.register_message_handler(send_stories_prices, lambda msg: msg.text == "🚀 Buy Stories")
    dp.register_message_handler(send_live_prices, lambda msg: msg.text == "🤹‍♂ Buy Live")
