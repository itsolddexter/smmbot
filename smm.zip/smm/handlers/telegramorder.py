from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher
import re
import random
import string
import sqlite3
from config import ADMIN_ID
from handlers.telegramservice import send_members_prices, send_reactions_prices, send_tgviews_prices

tg_order_state = {}

valid_services = {
    "1k Telegram Members ₹30": "Members",
    "5k Telegram Members ₹130": "Members",
    "10k Telegram Members ₹600": "Members",
    "1k Telegram Reaction ₹25": "Reaction",
    "5k Telegram Reaction ₹110": "Reaction",
    "10k Telegram Reaction ₹190": "Reaction",
    "1k Telegram Post Views ₹135": "Post Views",
    "5k Telegram Post Views ₹650": "Post Views",
    "10k Telegram Post Views ₹1100": "Post Views"
}

def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))

def extract_tg_link(text):
    tg_domains = [
        "t.me/",
        "telegram.me/",
        "telegram.dog/",
        "tg://resolve?domain=",
        "tg.nrw/",
        "teleg.run/",
        "tgram.link/",
        "telesco.pe/",
        "tginfo.me/",
        "tlgrm.eu/"
    ]
    
    for domain in tg_domains:
        if domain in text:
            return text
    return None

async def handle_order_selection(message: Message):
    if message.text not in valid_services:
        return
    tg_order_state[message.from_user.id] = {
        "service": message.text,
        "step": "awaiting_telegram_link"
    }
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("✖ Cancel Order"))
    await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Please send the Telegram Channel/ Group/Post link:</i></b>", reply_markup=keyboard, parse_mode="HTML")

async def process_tg_link(message: Message):
    user_id = message.from_user.id
    if user_id not in tg_order_state:
        return
    state = tg_order_state[user_id]
    if state.get("step") != "awaiting_telegram_link":
        return
    tg_link = extract_tg_link(message.text)
    if not tg_link:
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Invalid Telegram link. Please resend.</b>", parse_mode="HTML")
        return
    order_id = generate_order_id()
    state["step"] = "awaiting_tgpayment"
    state["username"] = tg_link
    state["order_id"] = order_id
    service_text = state['service']
    amount = service_text.split("\u20b9")[-1]
    service_name = service_text.replace(f"₹{amount}", "").strip()
    caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Telegram Order Details</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Amount To Pay:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order_id}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Target:</b> <code>{tg_link}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Note:</b> <code>⚠️ If you have sent the payment, please send a screenshot below.</code>"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("✖ Cancel Order"))
    await message.answer_photo("https://iili.io/3wsXU0u.jpg", caption=caption, parse_mode="HTML", reply_markup=keyboard)

async def cancel_o4der(message: Message):
    user_id = message.from_user.id
    if user_id in tg_order_state:
        service = tg_order_state[user_id].get("service")
        del tg_order_state[user_id]
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order has been cancelled.</b>", parse_mode="HTML")
        await redirect_to_service(message, service)

async def handle_payment_screenshot(message: Message):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    if user_id in tg_order_state and message.photo:
        order = tg_order_state[user_id]
        del tg_order_state[user_id]
        amount = order['service'].split("\u20b9")[-1]
        service_name = order['service'].replace(f"₹{amount}", "").strip()
        caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] New Telegram Order Received</b>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order['order_id']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Amount Been Pay:</b> <code>₹{amount}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>{service_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Target:</b> <code>{order['username']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] User:</b> <a href='tg://user?id={user_id}'>{first_name}</a>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Action:</b> This order is awaiting approval."""
        await message.bot.send_photo(ADMIN_ID, message.photo[-1].file_id, caption=caption, parse_mode="HTML")
        conn = sqlite3.connect("user_data.db")
        cur = conn.cursor()
        cur.execute("UPDATE users SET telegram_service = telegram_service + 1 WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        
        confirmation = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Hindi:</b>  
<pre>आपका ऑर्डर प्रोसेस हो रहा है ⚙️  
कृपया धैर्य रखें ⏳  
8 घंटे के अंदर आपका ऑर्डर पूरा कर दिया जाएगा ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] English:</b>  
<pre>Your order is currently being processed ⚙️  
Please be patient ⏳  
Your order will be completed within 8 hours ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Note:</b>  
<code>If you didn’t receive the order, please contact our support team or join the group.</code>"""
        await message.answer(confirmation, parse_mode="HTML")
        await redirect_to_service(message, order["service"])

async def redirect_to_service(message: Message, service: str):
    if "Members" in service:
        await send_members_prices(message)
    elif "Reaction" in service:
        await send_reactions_prices(message)
    elif "Post Views" in service:
        await send_tgviews_prices(message)

def register_tgorder_handlers(dp: Dispatcher):
    dp.register_message_handler(cancel_o4der, lambda m: m.text == "✖ Cancel Order")
    dp.register_message_handler(handle_order_selection, lambda m: m.text in valid_services)
    dp.register_message_handler(process_tg_link, lambda m: tg_order_state.get(m.from_user.id, {}).get("step") == "awaiting_telegram_link")
    dp.register_message_handler(
    handle_payment_screenshot,
    lambda m: tg_order_state.get(m.from_user.id, {}).get("step") == "awaiting_tgpayment",
    content_types=types.ContentType.PHOTO
)

