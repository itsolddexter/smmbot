from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher

#async def send_youtube_menu(message: Message):
#    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
#    keyboard.add(
#        KeyboardButton("⚡ Buy Followers"), KeyboardButton("❤ Buy Likes")
#    )
#    keyboard.add(
#        KeyboardButton("✅ Buy Comments"), KeyboardButton("👁 Buy Views")
#    )
#    keyboard.add(
#        KeyboardButton("🚀 Buy Stories"), KeyboardButton("🤹‍♂ Buy Live")
#    )
#    keyboard.add(
#        KeyboardButton("《 Back"), KeyboardButton("《 Dashboard")
#    )

#    caption = (
#        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>{}</b> This is our Instagram Service !!\n"
#        "<i>Please select a service below!</i>"
#    )
#    name = message.from_user.first_name
#    await message.answer(caption.format(name), reply_markup=keyboard, parse_mode="HTML")


async def send_subscribers_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Youtube Subscriber ₹205"))
    keyboard.add(KeyboardButton("5k Youtube Subscriber ₹900"))
    keyboard.add(KeyboardButton("10k Youtube Subscriber ₹1800"))
    keyboard.add(KeyboardButton("《 Back"), KeyboardButton("《 Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your YouTube Subscribres package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_ytlikes_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Youtube Likes ₹65"))
    keyboard.add(KeyboardButton("5k Youtube Likes ₹300"))
    keyboard.add(KeyboardButton("10k Youtube Likes ₹500"))
    keyboard.add(KeyboardButton("《 Back"), KeyboardButton("《 Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your YouTube Likes package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_ytviews_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Youtube Views ₹110"))
    keyboard.add(KeyboardButton("5k Youtube Views ₹500"))
    keyboard.add(KeyboardButton("10k Youtube Views ₹900"))
    keyboard.add(KeyboardButton("《 Back"), KeyboardButton("《 Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your YouTube Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_stream_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Youtube Live Stream Views ₹50"))
    keyboard.add(KeyboardButton("5k Youtube Live Stream Views ₹200"))
    keyboard.add(KeyboardButton("10k Youtube Live Stream Views ₹350"))
    keyboard.add(KeyboardButton("《 Back"), KeyboardButton("《 Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your YouTube Live Stream Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

def register_ytservice_handlers(dp: Dispatcher):
    dp.register_message_handler(send_subscribers_prices, lambda msg: msg.text == "🚀 Buy Subscribers")
    dp.register_message_handler(send_ytlikes_prices, lambda msg: msg.text == "💖 Buy Likes")
    dp.register_message_handler(send_ytviews_prices, lambda msg: msg.text == "📈 Buy Views")
    dp.register_message_handler(send_stream_prices, lambda msg: msg.text == "🎯 Buy Stream Views")
