import sqlite3
import asyncio
from aiogram import types
from aiogram.dispatcher import Dispatcher
from config import ADMIN_ID

broadcast_targets = {}

async def broadcast_command_handler(message: types.Message):
    print("Broadcast command received from:", message.from_user.id)
    if message.from_user.id != ADMIN_ID:
        return
    await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Please reply to a message you want to broadcast to all users:</b>", parse_mode="HTML")
    broadcast_targets[message.from_user.id] = True

async def forward_broadcast_handler(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    if not broadcast_targets.get(message.from_user.id):
        return
    broadcast_targets[message.from_user.id] = False
    asyncio.create_task(start_broadcasting(message))

async def start_broadcasting(message: types.Message):
    with sqlite3.connect("user_data.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users")
        users = cursor.fetchall()

    sent, failed = 0, 0
    failed_users = []
    status_msg = await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Broadcast Started......</b>", parse_mode="HTML")

    for i, user in enumerate(users):
        try:
            await message.bot.forward_message(chat_id=user[0], from_chat_id=message.chat.id, message_id=message.message_id)
            sent += 1
        except:
            failed += 1
            failed_users.append(str(user[0]))
        await asyncio.sleep(0.05)
        if i % 25 == 0:
            await status_msg.edit_text(
                f"<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] </b><code>Broadcasting In Progress...</code>\n"
                 f"- - - - - - - - - - - - - - - - - - - - - - - -\n"
                 f"<b>✅ Delivered:</b> <code>{sent}</code>\n"
                f"<b>❌ Failed:</b> <code>{failed}</code>\n"
                f"- - - - - - - - - - - - - - - - - - - - - - - -\n"
                f"<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Developer:</b> <a href='tg://user?id=6938095972'>Sandesh Vaiya</a>",
                parse_mode="HTML"
            )

    if failed_users:
        with open("failed_users.txt", "w") as f:
            f.write("\n".join(failed_users))

    await status_msg.edit_text(
        f"<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Broadcast Completed! ✅</b>\n"
        f"- - - - - - - - - - - - - - - - - - - - - - - -\n"
        f"<b>✅ Delivered:</b> <code>{sent}</code>\n"
        f"<b>❌ Failed:</b> <code>{failed}</code>\n"
        f"<b>📦 Saved failed IDs:</b> <code>{'Yes' if failed else 'No'}</code>\n"
        f"- - - - - - - - - - - - - - - - - - - - - - - -\n"
        f"<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Developer:</b> <a href='tg://user?id=6938095972'>Sandesh Vaiya</a>",
        parse_mode="HTML"
    )


#def register_broadcast_handlers(dp: Dispatcher):
#	dp.register_message_handler(broadcast_command_handler, commands=["cast"])
#	dp.register_message_handler(forward_broadcast_handler, content_types=types.ContentType.ANY)

