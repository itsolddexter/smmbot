from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.dispatcher import Dispatcher

#async def send_youtube_menu(message: Message):
#    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
#    keyboard.add(
#        KeyboardButton("⚡ Buy Followers"), KeyboardButton("❤ Buy Likes")
#    )
#    keyboard.add(
#        KeyboardButton("✅ Buy Comments"), KeyboardButton("👁 Buy Views")
#    )
#    keyboard.add(
#        KeyboardButton("🚀 Buy Stories"), KeyboardButton("🤹‍♂ Buy Live")
#    )
#    keyboard.add(
#        KeyboardButton("❮❮ Back"), KeyboardButton("❮❮ Dashboard")
#    )

#    caption = (
#        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b>{}</b> This is our Instagram Service !!\n"
#        "<i>Please select a service below!</i>"
#    )
#    name = message.from_user.first_name
#    await message.answer(caption.format(name), reply_markup=keyboard, parse_mode="HTML")


async def send_members_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Telegram Members ₹30"))
    keyboard.add(KeyboardButton("5k Telegram Members ₹130"))
    keyboard.add(KeyboardButton("10k Telegram Members ₹600"))
    keyboard.add(KeyboardButton("❮❮ Back"), KeyboardButton("❮❮ Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Telegram Channel / Groups Members package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_reactions_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Telegram Reaction ₹25"))
    keyboard.add(KeyboardButton("5k Telegram Reaction ₹110"))
    keyboard.add(KeyboardButton("10k Telegram Reaction ₹190"))
    keyboard.add(KeyboardButton("❮❮ Back"), KeyboardButton("❮❮ Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Telegram Reaction package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

async def send_tgviews_prices(message: Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("1k Telegram Post Views ₹135"))
    keyboard.add(KeyboardButton("5k Telegram Post Views ₹650"))
    keyboard.add(KeyboardButton("10k Telegram Post Views ₹1100"))
    keyboard.add(KeyboardButton("❮❮ Back"), KeyboardButton("❮❮ Dashboard"))
    await message.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b> <b><i>Choose your Telegram Post Views package:</i></b>",
        reply_markup=keyboard, parse_mode="HTML"
    )

def register_tgservice_handlers(dp: Dispatcher):
    dp.register_message_handler(send_members_prices, lambda msg: msg.text == "✨ Buy Members")
    dp.register_message_handler(send_reactions_prices, lambda msg: msg.text == "🔥 Buy Reaction")
    dp.register_message_handler(send_tgviews_prices, lambda msg: msg.text == "📈 Buy Post Views")

