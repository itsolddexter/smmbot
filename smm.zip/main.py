import asyncio
import sqlite3
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from handlers.start import start_handler, check_callback_handler, menu
from handlers.othercmd import instagram_handler, youtube_handler, telegram_handler
from handlers.command import (
    me_handler, 
    refer_handler, 
    stats_handler,
    getfree_command,
    process_free_username,
    cancel_free_order,
    handle_free_payment_screenshot,
    user_free_order_state
)
from handlers.instaservice import  register_instaservice_handlers
from handlers.instaorder import register_instaorder_handlers
from handlers.youtubeservice import register_ytservice_handlers
from handlers.ytorder import register_ytorder_handlers
from handlers.telegramservice import register_tgservice_handlers
from handlers.telegramorder import register_tgorder_handlers
from handlers.bccast import broadcast_command_handler, forward_broadcast_handler
from config import BOT_TOKEN

bot = Bot(token=BOT_TOKEN, parse_mode="HTML")
dp = Dispatcher(bot)

def init_db():
    conn = sqlite3.connect('user_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            referred INTEGER DEFAULT 0,
            referby INTEGER DEFAULT 0,
            balance INTEGER DEFAULT 0,
            refer TEXT DEFAULT '',
            instagram_service INTEGER DEFAULT 0,
            telegram_service INTEGER DEFAULT 0,
            youtube_service INTEGER DEFAULT 0
        )
    ''')
    conn.commit()
    conn.close()

def init_global_db():
    conn = sqlite3.connect('global_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS global_stats (
            key TEXT PRIMARY KEY,
            value INTEGER DEFAULT 0
        )
    ''')
    cursor.execute("INSERT OR IGNORE INTO global_stats (key, value) VALUES ('total_users', 0)")
    conn.commit()
    conn.close()

init_db()
init_global_db()

# ===== Register Service Handlers =====
register_tgservice_handlers(dp)
register_tgorder_handlers(dp)

register_ytservice_handlers(dp)
register_ytorder_handlers(dp)

register_instaservice_handlers(dp)
register_instaorder_handlers(dp)

# ===== Command Handlers =====
dp.register_message_handler(start_handler, commands=["start"])
dp.register_message_handler(me_handler, commands=["me"])
dp.register_message_handler(refer_handler, commands=["refer"])
dp.register_message_handler(stats_handler, commands=["stats"])
dp.register_message_handler(getfree_command, commands=["getfree-insta-10k-followers"])
dp.register_message_handler(broadcast_command_handler, commands=["broadcast"])

# ===== Callback Query Handler =====
dp.register_callback_query_handler(check_callback_handler, lambda c: c.data == "check")

# ===== Text-based Service Handlers =====
@dp.message_handler(lambda msg: msg.text in ["« Back", "« Dashboard", "《 Dashboard", "❮❮ Dashboard"])
async def handle_back_or_dashboard(msg: Message):
    await menu(msg.bot, msg.from_user.id)

dp.register_message_handler(instagram_handler, lambda msg: msg.text in ["Instagram Service", "‹‹ Back"])

dp.register_message_handler(youtube_handler, lambda msg: msg.text in ["YouTube Service", "《 Back"])

dp.register_message_handler(telegram_handler, lambda msg: msg.text in ["Telegram Service", "❮❮ Back"])

dp.register_message_handler(cancel_free_order, lambda m: m.text == "❌ 𝑪𝒂𝒏𝒄𝒆𝒍 𝑶𝒓𝒅𝒆𝒓")

# ===== Media Handler =====
dp.register_message_handler(handle_free_payment_screenshot, content_types=types.ContentType.PHOTO)

dp.register_message_handler(forward_broadcast_handler, content_types=types.ContentType.ANY)

# ===== Catch-All Username Handler =====
dp.register_message_handler(process_free_username, lambda m: user_free_order_state.get(m.from_user.id, {}).get("step") == "awaiting_free_username")

async def main():
    await dp.start_polling()

if __name__ == "__main__":
    asyncio.run(main())
