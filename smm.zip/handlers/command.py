import random
import re
import string
import sqlite3
import instaloader
from aiogram import types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from config import ADMIN_ID, PER_REFER, coin
from handlers.start import menu

user_free_order_state = {}

async def me_handler(msg: Message):
    bot = msg.bot
    user_id = msg.from_user.id
    bot_info = await bot.get_me()

    await msg.delete()

    conn = sqlite3.connect("user_data.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cur.fetchone()
    conn.close()

    if user:
        refer_url = f"https://t.me/{bot_info.username}?start={user_id}"
        text = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Your Account Database:</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] User ID:</b> <code>{user_id}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Wallet:</b> <code>{user['balance']} {coin}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Referrals:</b> <code>{user['referred']}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Instagram Orders:</b> <code>{user['instagram_service']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Telegram Orders:</b> <code>{user['telegram_service']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] YouTube Orders:</b> <code>{user['youtube_service']}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Tip:</b><code> ⚠️ Refer more users to earn extra balance!</code>"""

        share_markup = InlineKeyboardMarkup().add(
            InlineKeyboardButton(
                "🔗 Share Your Refer Link",
                url=f"https://t.me/share/url?url={refer_url}"
            )
        )

        await bot.send_video(
            chat_id=user_id,
            video="https://t.me/SandeshClaude/7",
            caption=text,
            parse_mode="HTML",
          #  disable_web_page_preview=True,
            reply_markup=share_markup
        )

    else:
        register_link = f"https://t.me/{bot_info.username}?start=6938095972"
        markup = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🖋 Register", url=register_link)
        )

        await msg.answer(
            "<b><i>⚠️ You are not registered yet.</i></b>\n\n<b>Click below to register yourself:</b>",
            parse_mode="HTML",
            reply_markup=markup
        )

async def refer_handler(msg: Message):
    bot = msg.bot
    user_id = msg.from_user.id
    bot_info = await bot.get_me()

    await msg.delete()

    conn = sqlite3.connect("user_data.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT referred FROM users WHERE id = ?", (user_id,))
    user = cur.fetchone()
    conn.close()

    if user:
        refer_link = f"https://t.me/{bot_info.username}?start={user_id}"
        caption = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Invite & Earn Panel</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Your Referral Link:</b> <b>{refer_link}</b>

<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Per Refer:</b> <code>{PER_REFER} {coin}</code>

<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Your Total Referrals:</b> <code>{user['referred']}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Tip:</b> <code>⚠️ Earn instant balance on each user's registration!</code>
"""
        markup = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🔗 Share Refer Link", url=f"https://t.me/share/url?url={refer_link}")
        )

        #await msg.answer(caption, parse_mode="HTML", disable_web_page_preview=True, reply_markup=markup)
        await bot.send_video(
            chat_id=user_id,
            video="https://t.me/SandeshClaude/7",
            caption=caption,
            parse_mode="HTML",
          #  disable_web_page_preview=True,
            reply_markup=markup
        )

    else:
        register_link = f"https://t.me/{bot_info.username}?start=6938095972"
        markup = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🖋 Register", url=register_link)
        )

        await msg.answer(
            "<b><i>⚠️ You are not registered yet.</i></b>\n\n<b>Click below to register yourself:</b>",
            parse_mode="HTML",
            reply_markup=markup
        )        
        
async def stats_handler(msg: Message):
    bot = msg.bot
    user_id = msg.from_user.id
    bot_info = await bot.get_me()

    await msg.delete()

    conn_user = sqlite3.connect("user_data.db")
    conn_user.row_factory = sqlite3.Row
    cur_user = conn_user.cursor()
    cur_user.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cur_user.fetchone()
    conn_user.close()

    if not user:
        keyboard = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🖌 Register", url=f"https://t.me/{(await bot.get_me()).username}?start={user_id}")
        )
        await msg.reply(
            "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b><code> You are not registered yet.</code>",
            parse_mode="HTML",
            reply_markup=keyboard
        )
        return

    conn_global = sqlite3.connect("global_data.db")
    cur_global = conn_global.cursor()
    cur_global.execute("SELECT value FROM global_stats WHERE key = 'total_users'")
    total_users = cur_global.fetchone()[0]
    conn_global.close()

    text = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>]</b><code> Bot Stats:</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Total Users:</b> <code>{total_users}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Developer:</b> <code>Sandesh Vaiya</code>"""

    refer_link = f"https://t.me/{(await bot.get_me()).username}?start={user_id}"
    share_url = f"https://t.me/share/url?url={refer_link}"

    keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton("🔗 Share Your Refer Link", url=share_url)
    )

    await bot.send_video(
            chat_id=user_id,
            video="https://t.me/SandeshClaude/7",
            caption=text,
            parse_mode="HTML",
          #  disable_web_page_preview=True,
            reply_markup=keyboard
        )
        
def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))

def extract_username(text):
    match = re.search(r"(?:https?://)?(?:www\.)?instagram\.com/([\w\.]+)|@?(\w+)", text)
    if match:
        return match.group(1) or match.group(2)
    return None

async def getfree_command(msg: Message):
    bot = msg.bot
    user_id = msg.from_user.id
    bot_info = await bot.get_me()
    conn = sqlite3.connect("user_data.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT referred, balance FROM users WHERE id = ?", (user_id,))
    row = cur.fetchone()
    user = row
    conn.close()

    if not row or row["balance"] < 50:
        refer_link = f"https://t.me/{bot_info.username}?start={user_id}"
        
        message = f"""<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>]</b><code> Invite & Earn Panel</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Your Referral Link:</b> <b>{refer_link}</b>

<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Per Refer:</b> <code>{PER_REFER} {coin}</code>

<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Your Total Referrals:</b> <code>{user['referred']}</code>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Required Balance:</b> <code>50</code>
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Current Balance:</b> <code>{user['balance']}</code>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Tip:</b> <code>⚠️ Refer others to increase your balance & claim Free Followers!</code>"""

        markup = InlineKeyboardMarkup().add(
            InlineKeyboardButton("🔗 Share Refer Link", url=f"https://t.me/share/url?url={refer_link}")
        )
        
        await bot.send_video(
            chat_id=user_id,
            video="https://t.me/SandeshClaude/7",
            caption=message,
            parse_mode="HTML",
            reply_markup=markup
        )
        
        return

    user_free_order_state[user_id] = {"step": "awaiting_free_username"}
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("❌ 𝑪𝒂𝒏𝒄𝒆𝒍 𝑶𝒓𝒅𝒆𝒓"))
    await msg.answer(
        "<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Please send your Instagram username or profile link:</b>",
        reply_markup=keyboard,
        parse_mode="HTML"
    )

async def process_free_username(message: Message):
    user_id = message.from_user.id
    if user_id not in user_free_order_state:
        return

    state = user_free_order_state[user_id]
    if state.get("step") != "awaiting_free_username":
        return

    username = extract_username(message.text)
    if not username:
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Invalid username. Please resend.</b>", parse_mode="HTML")
        return

    loader = instaloader.Instaloader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
        if profile.is_private:
            del user_free_order_state[user_id]
            await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] This account is private. Please make it public.</b>", parse_mode="HTML")
            await menu(message.bot, user_id)
            return
    except:
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Couldn't fetch profile. Please resend a valid username.</b>", parse_mode="HTML")
        return

    order_id = generate_order_id()
    bio = profile.biography or "Not Available!!!"
    followers = profile.followers
    state["step"] = "awaiting_payment"
    state["username"] = username
    state["order_id"] = order_id
    state["bio"] = bio
    state["followers"] = followers

    caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Instagram Order Details (Free)</b>
- - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Amount To Pay:</b> <code>₹0</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>Free Followers</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order_id}</code>
- - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>👁‍🗨</a>] Account Info:</b>

<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Username:</b> <code>{profile.username}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Name:</b> <code>{profile.full_name}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Followers:</b> <code>{followers}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Bio:</b> <code>{bio}</code>
- - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Note:</b> <code>Send screenshot after sending payment (Free offer)</code>"""

    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("❌ 𝑪𝒂𝒏𝒄𝒆𝒍 𝑶𝒓𝒅𝒆𝒓"))
    await message.answer_photo("https://iili.io/3wsXU0u.jpg", caption=caption, parse_mode="HTML", reply_markup=keyboard)

async def cancel_free_order(message: Message):
    user_id = message.from_user.id
    if user_id in user_free_order_state:
        del user_free_order_state[user_id]
        await message.answer("<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order Cancelled Successfully</b>", parse_mode="HTML")
        await menu(message.bot, user_id)

async def handle_free_payment_screenshot(message: Message):
    user_id = message.from_user.id
    if user_id in user_free_order_state and message.photo:
        order = user_free_order_state[user_id]
        del user_free_order_state[user_id]

        conn = sqlite3.connect("user_data.db")
        cur = conn.cursor()
        cur.execute("UPDATE users SET balance = balance - 50, instagram_service = instagram_service + 1 WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()

        caption = f"""<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] New Free Follower Order</b>
- - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Order ID:</b> <code>{order['order_id']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Service:</b> <code>Free Followers</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Username:</b> <code>{order['username']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Followers:</b> <code>{order['followers']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Bio:</b> <code>{order['bio']}</code>
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] User:</b> <a href="tg://user?id={user_id}">{message.from_user.first_name}</a>
- - - - - - - - - - - - - - - - - - - -
<b>[<a href='https://t.me/SocialSphereBot_Helpline'>ϟ</a>] Note:</b> <i>This is a Free Order (balance deducted)</i>"""

        await message.bot.send_photo(ADMIN_ID, message.photo[-1].file_id, caption=caption, parse_mode="HTML")

        confirmation = """<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Hindi:</b>  
<pre>आपका ऑर्डर प्रोसेस हो रहा है ⚙️  
कृपया धैर्य रखें ⏳  
8 घंटे के अंदर आपका ऑर्डर पूरा कर दिया जाएगा ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] English:</b>  
<pre>Your order is currently being processed ⚙️  
Please be patient ⏳  
Your order will be completed within 8 hours ✅</pre>
- - - - - - - - - - - - - - - - - - - - - - - -
<b>[<a href="https://t.me/SocialSphereBot_Helpline">ϟ</a>] Note:</b>  
<code>If you didn’t receive the order, please contact our support team or join the group.</code>"""
        await message.answer(confirmation, parse_mode="HTML")
        await menu(message.bot, user_id)        